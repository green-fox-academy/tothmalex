package com.greenfoxacademy.simbabank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimbabankApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimbabankApplication.class, args);
	}
}
